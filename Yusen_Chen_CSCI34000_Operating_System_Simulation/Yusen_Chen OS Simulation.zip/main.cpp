//Yusen Chen
#include "simulatedOS.h"

int main()
{
    simulatedOS simulation = simulatedOS();
    simulation.startSimulation();
    return 0;
}



Please compile as:

g++ -std=c++17 -g -fsanitize=address,undefined pid.cpp simulatedRam.cpp hardDisk.cpp theQueues.cpp simulatedOS.cpp main.cpp -o a.out